agate is made by a community. The following individuals have contributed code, documentation, or expertise to agate:

* `Christopher Groskopf <https://github.com/onyxfish/>`_
* `Jeff Larson <https://github.com/thejefflarson>`_
* `Eric Sagara <https://github.com/esagara>`_
* `John Heasly <https://github.com/jheasly>`_
* `Mick O'Brien <https://github.com/mickaobrien>`_
* `David Eads <https://github.com/eads>`_
* `Nikhil Sonnad <https://github.com/nsonnad>`_
* `Matt Riggott <https://github.com/flother>`_
* `Tyler Fisher <https://github.com/TylerFisher>`_
* `William P. Davis <https://github.com/wpdavis>`_
* `Ryan Murphy <https://github.com/rdmurphy>`_
* `Raphael Deem <https://github.com/r0fls>`_
* `Robin Linderborg <https://github.com/miroli>`_
* `Chris Keller <https://github.com/chrislkeller>`_
* `Neil Bedi <https://github.com/nbedi>`_
* `Geoffrey Hing <https://github.com/ghing>`_
* `Taurus Olson <https://github.com/TaurusOlson>`_
* `Danny Page <https://github.com/dannypage>`_
* `James McKinney <https://github.com/jpmckinney>`_
* `Tony Papousek <https://github.com/tonypapousek>`_
* `Mila Frerichs <https://github.com/milafrerichs>`_
* `Paul Fitzpatrick <https://github.com/paulfitz>`_
* `Ben Welsh <https://github.com/palewire>`_
* `Kevin Schaul <https://github.com/kevinschaul>`_
* `sandyp <https://github.com/sandyp>`_
* `Lexie Heinle <https://github.com/lexieheinle>`_
* `Will Skora <https://github.com/skorasaurus>`_
* `Joe Germuska <https://github.com/JoeGermuska>`_
* `Eli Murray <https://github.com/ejmurra>`_
* `Derek Swingley <https://github.com/swingley>`_
* `Or Sharir <https://github.com/orsharir>`_
* `Anthony DeBarros <https://github.com/anthonydb>`_
* `Apoorv Anand <https://github.com/apoorv74>`_
* `Ghislain Antony Vaillant <https://github.com/ghisvail>`_
* `Neil MartinsenBurrell <https://github.com/neilmb>`_
* `Aliaksei Urbanski <https://github.com/Jamim>`_
* `Forest Gregg <https://github.com/fgregg>`_
* `Robert Schütz <https://github.com/dotlambda>`_
* `Wouter de Vries <https://github.com/wadevries>`_
* `Kartik Agaram <https://github.com/akkartik>`_
* `Loïc Corbasson <https://github.com/lcorbasson>`_
* `Danny Sepler <https://github.com/dannysepler>`_
* `brian-from-quantrocket <https://github.com/brian-from-quantrocket>`_
* `mathdesc <https://github.com/mathdesc>`_
* `Tim Gates <https://github.com/timgates42>`_
* `castorf <https://github.com/castorf>`_
* `Julien Enselme <https://github.com/Jenselme>`__

